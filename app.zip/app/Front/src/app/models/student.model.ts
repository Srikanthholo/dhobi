export class Students{

    _id: string='';
    username: string='';
    email: string='';
   password: string='';
   roles: any;
 
}


